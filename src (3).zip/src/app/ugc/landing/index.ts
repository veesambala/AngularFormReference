export { UgcLandingModule } from './landing.module';
