import { Component } from '@angular/core';
@Component({
  selector: 'ugc-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent {
}