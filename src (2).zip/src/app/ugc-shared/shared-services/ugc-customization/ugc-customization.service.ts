import { Injectable } from '@angular/core';
import { PlatformHttpService } from '../platform-http/platform-http.service';
import { Observable, Subject } from 'rxjs';
import { ConfigService } from '../../../core/services/config/config.service';
import { Http } from '@angular/http';
import { StaticUtils } from '../static-utils';
import { ObservableInput } from 'rxjs/Observable';
import { UgcC11nJson, CustomizationFactory } from '../../shared-factories/customization.factory';

/**
 * UgcCustomizationService handles UGC C11N JSON and its validation
 */
@Injectable()
export class UgcCustomizationService {
      public static UgcUrl(): string {
        return 'assets/mock-data/ugc-config.json';
    }

    public static mockMasterUrl(): string {
        return 'assets/mock-data/ugc-config.json';
    }

    public static masterUrl(): string {
        return 'assets/mock-data/ugc-config.json';
    }
    public ugcConfigC11n: UgcC11nJson = null;
    private _ugcConfigURL = 'assets/mock-data/ugc-config.json';
    private _loadErrors: Array<string> = [];
    private _loadWarnings: Array<string> = [];

    constructor(
        private _http: Http,
        private _configService: ConfigService
    ) {
    }

   /**
    * @return {UgcC11nJson} The latest customization json that has been loaded from the server, or null if one has not been
    */
    public get ugcC11n(): UgcC11nJson {
        return this.ugcConfigC11n;
    }
    public set ugcC11n(data: UgcC11nJson) {
        this.ugcConfigC11n = data;
    }
  /**
   * @return {Array<string>} Any errors that occurred while loading the c11n files
   */
    get loadErrors(): Array<string> {
        return this._loadErrors;
     }
  /**
   * @return {Array<string>} Any warnings that occurred while loading the c11n files
   */
  get loadWarnings(): Array<string> {
    return this._loadWarnings;
  }

  /**
   * @return {Promise<any>} A promise related to the request to get the customization
   */
  public load(): Promise<any> {
    return this.getUgcJsonFromServer();
  }

  /**
   * Get the C11N data of UGC
   */
    public getUgcC11n(): Observable<any> {
        return this._http.get(
            this.ugcC11nUrl()
        ).map((response: any) => {
            return response.json();
        });
    }

    private UgcLoader(): Observable<any> {
        let url: string = StaticUtils.IS_LOCALHOST ? UgcCustomizationService.mockMasterUrl() :
        UgcCustomizationService.UgcUrl();
        return this._http.get(url)
          .retry(3)
          .catch((requestError: any): ObservableInput<Response> => {
            this._loadErrors.push('error getting Ugc c11n: ' + requestError);
            return Observable.of(null);
          })
          .map((response: Response) => {
            try {
              return response.json();
            } catch (parseError) {
              this._loadErrors.push('error parsing Ugc c11n json: ' + parseError);
              return null;
            }
          });
    }

    private masterLoader(): Observable<any> {
        let url: string = StaticUtils.IS_LOCALHOST ? UgcCustomizationService.mockMasterUrl() :
        UgcCustomizationService.masterUrl();
        return this._http.get(url)
          .retry(3)
          .catch((requestError: any): ObservableInput<Response> => {
            this._loadErrors.push('error getting master c11n: ' + requestError);
            return Observable.of(null);
          })
          .map((response: Response) => {
            try {
              return response.json();
            } catch (parseError) {
              this._loadErrors.push('error parsing master c11n json: ' + parseError);
              return null;
            }
          });
    }

    private getUgcJsonFromServer(): Promise<any> {
        return new Promise((resolve, reject) => {
          let UgcRequest = this.UgcLoader();
          let masterRequest = this.masterLoader();
          let UgcJsonLoader = Observable.zip(masterRequest, UgcRequest,
            (masterCustomization, UgcCustomization) => {
              if (!masterCustomization) {
                this._loadErrors.push('could not load the master c11n, setting to empty object');
                masterCustomization = {};
              }
              if (!UgcCustomization) {
                this._loadWarnings.push('could not load the UGC c11n, setting to empty object');
                UgcCustomization = {};
              } else {
                let ugcErrors: Array<string> = CustomizationFactory.validateC11nJson(
                    JSON.parse(JSON.stringify(UgcCustomization)),
                    'c11n',
                    false);
                if (ugcErrors.length > 0) {
                  this._loadErrors.push('Ugc c11n was not formatted correctly; errors: ' 
                                        + ugcErrors.toString());
                }
              }
              StaticUtils.smartMergeObjects(masterCustomization, UgcCustomization);

              let UgcC11n: UgcC11nJson = masterCustomization as UgcC11nJson;
              let c11nErrors: Array<string> =  CustomizationFactory.validateC11nJson(
                masterCustomization,
                'UgcC11n',
                false);

              if (c11nErrors.length > 0) {
                this._loadErrors.push('combined Ugc c11n was not formatted correctly; errors: '
                                      + c11nErrors.toString());
              }
              return UgcC11n;
            }
          );
          UgcJsonLoader.subscribe(
            (c11n) => {
              this.ugcConfigC11n = c11n;
              resolve(c11n);
            },
            (error: any) => {
              reject(error);
            }
          );
        });
    }

    private ugcC11nUrl(): string {
        return this.ugcC11nBaseUrl() + '/';
    }

    private ugcC11nBaseUrl(): string {
        return this._configService.config.platformBaseUrl + '/';
    }

}
