import { NgModule } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
// import { CustomFormsModule } from 'ng2-validation'
import { CommonModule } from "@angular/common";
import { UploadComponent } from './upload.component';
import { ViewportModule } from 'angular2-viewport';
import { routes } from './upload.routes';
import { RouterModule } from '@angular/router';
import { sharedComponentsModule } from '../../ugc-shared/shared-components/shared-components.module';
import { SharedServicesModule} from '../../ugc-shared/shared-services/shared-services.module';
import { UploadFIPreviewComponent } from './media-preview-container/upload-fi-preview/upload-fi-preview.component';
import { UploadUserInfoComponent}  from './media-user-info-container/upload-user-info/upload-user-info.component';
import { UploadConfirmComponent } from './upload-confirm/upload-confirm.component';
import { UploadUserInfoMobileComponent } from './media-user-info-container/upload-user-info-mobile/upload-user-info-mobile.component';
import { UploadFIMobilePreviewComponent } from './media-preview-container/upload-fi-mobile-preview/upload-fi-mobile-preview.component'
import { UploadAddMediaComponent } from './upload-add-media-container/upload-add-media/upload-add-media.component';
import { UploadAddMediaMobileComponent } from './upload-add-media-container/upload-add-media-mobile/upload-add-media-mobile.component';
import { UploadInProgressComponent } from './upload-in-progress-container/upload-in-progress/upload-in-progress.component';
import { UploadInProgressMobileComponent } from './upload-in-progress-container/upload-in-progress-mobile/upload-in-progress-mobile.component';
import { UploadSuccessComponent } from './upload-success/upload-success.component';
import { UploadSuccessMobileComponent } from './upload-success-mobile/upload-success-mobile.component';
import { UploadTermsConditionsComponent } from './media-terms-conditions-container/upload-terms-conditions/upload-terms-conditions.component';
import { UploadTermsConditionsMobileComponent } from './media-terms-conditions-container/upload-terms-conditions-mobile/upload-terms-conditions-mobile.component';
import { UploadAddMediaContainerComponent } from './upload-add-media-container/upload-add-media-container.component';
import { MediaTermsConditionsContainerComponent } from './media-terms-conditions-container/media-terms-conditions-container.component';
import { MediaPreviewContainerComponent } from './media-preview-container/media-preview-container.component';
import { MediaUserInfoContainerComponent } from './media-user-info-container/media-user-info-container.component';
import { UploadInProgressContainerComponent } from './upload-in-progress-container/upload-in-progress-container.component';


@NgModule({
    declarations: [
        UploadComponent,
        UploadFIPreviewComponent,
        UploadUserInfoComponent,
        UploadConfirmComponent,
        UploadUserInfoMobileComponent,
        UploadFIMobilePreviewComponent,
        UploadAddMediaMobileComponent,
        UploadAddMediaComponent,
        UploadInProgressComponent,
        UploadInProgressMobileComponent,
        UploadSuccessComponent,
        UploadSuccessMobileComponent,
        UploadTermsConditionsComponent,
        UploadTermsConditionsMobileComponent,
        UploadAddMediaContainerComponent,
        MediaPreviewContainerComponent,
        MediaUserInfoContainerComponent,
        UploadInProgressContainerComponent,
        MediaTermsConditionsContainerComponent
    ],
    imports: [sharedComponentsModule, FormsModule, CommonModule,ReactiveFormsModule,ViewportModule, RouterModule.forChild(routes)],
    exports: []
})
export class UploadModule {

}