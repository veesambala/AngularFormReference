import { TestBed, async } from '@angular/core/testing';
import { MediaTermsConditionsContainerComponent } from './media-terms-conditions-container.component';
describe('MediaTermsConditionsContainerComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MediaTermsConditionsContainerComponent
      ],
    }).compileComponents();
  }));
  it('should create the MediaTermsConditionsContainerComponent', async(() => {
    const fixture = TestBed.createComponent(MediaTermsConditionsContainerComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
