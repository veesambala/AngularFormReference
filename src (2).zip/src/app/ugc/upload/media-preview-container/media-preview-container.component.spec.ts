import { TestBed, async } from '@angular/core/testing';
import { UploadAddMediaContainerComponent } from './upload-add-media-container.component';
describe('UploadAddMediaContainerComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UploadAddMediaContainerComponent
      ],
    }).compileComponents();
  }));
  it('should create the UploadAddMediaComponent component', async(() => {
    const fixture = TestBed.createComponent(UploadAddMediaContainerComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
