import { Component, OnInit, Renderer2, ViewEncapsulation } from '@angular/core';
import { Router, NavigationEnd, NavigationStart } from '@angular/router';
import { AppState } from './shared/services/app/app.service';

import { ConfigService } from './core/services/config/config.service';
import { ClickTrackingService } from "./core/services/click-tracking/click-tracking.service";
import { CoreServicesManager } from "./core/services/core.services.manager";
import { LoggingService } from "./core/services/logging/logging.service";
import { Observable, Subject } from "rxjs";

@Component({
  selector: 'app',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './app.component.css'
  ],
  templateUrl: './app.component.html'
})
export class AppComponent {
  
  constructor(
    private _router: Router,
    private _coreServicesManager: CoreServicesManager,
    private _renderer: Renderer2,
    private _logging: LoggingService,
    private _config: ConfigService
  ) {
    this._coreServicesManager.configure(this._renderer);
  }
  

}
