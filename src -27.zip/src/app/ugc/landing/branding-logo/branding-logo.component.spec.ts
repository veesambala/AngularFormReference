import { TestBed, async } from '@angular/core/testing';
import { BrandingLogoComponent } from './branding-logo.component';

describe('BrandingLogoComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BrandingLogoComponent
      ],
    }).compileComponents();
  }));
  it('should create the BrandingLogoComponent', async(() => {
    const fixture = TestBed.createComponent(BrandingLogoComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
