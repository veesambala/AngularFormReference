import { TestBed, async } from '@angular/core/testing';
import { UploadAddMediaComponent } from './upload-add-media.component';
describe('UploadAddMediaComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UploadAddMediaComponent
      ],
    }).compileComponents();
  }));
  it('should create the UploadAddMediaComponent component', async(() => {
    const fixture = TestBed.createComponent(UploadAddMediaComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
