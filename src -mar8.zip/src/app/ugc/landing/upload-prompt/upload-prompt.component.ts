import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UgcCustomizationService } from
'../../../ugc-shared/shared-services/ugc-customization/ugc-customization.service';
import { UgcC11nJson } from '../../../ugc-shared/shared-factories/customization.factory';
import { QueryParams, StaticUtils } from '../../../ugc-shared/shared-services/static-utils';


@Component({
  selector: 'ugc-upload-prompt',
  templateUrl: './upload-prompt.component.html',
  styleUrls: ['./upload-prompt.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadPromptComponent {
  public ugcCustomizeConfig: UgcC11nJson;
  constructor(private _changeDetector: ChangeDetectorRef,
              private _ugcCustomize: UgcCustomizationService,
              private _router: Router) {
    this.ugcCustomizeConfig = this._ugcCustomize.ugcC11n;
    console.log(this.ugcCustomizeConfig);
  }

  public backToReturnUrl() {
    let returnUrl = this.ugcCustomizeConfig.returnUrl ? this.ugcCustomizeConfig.returnUrl : '';
    // navigate to return Url
  }
  public goToUpload() {
    let queryParams: QueryParams =  StaticUtils.queryParams;
    this._router.navigate(['/ugc/upload'], { queryParams: queryParams });
  }

  public onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  public onImageError(event): void {
    this._changeDetector.detectChanges();
  }
}
