import { TestBed, async } from '@angular/core/testing';
import { DesktopLandingComponent } from './desktop-landing.component';

describe('DesktopLandingComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DesktopLandingComponent
      ],
    }).compileComponents();
  }));
  it('should create the poweredBy component', async(() => {
    const fixture = TestBed.createComponent(DesktopLandingComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
