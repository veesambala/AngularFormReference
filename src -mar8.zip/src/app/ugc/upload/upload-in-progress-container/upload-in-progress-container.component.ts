import { Component } from '@angular/core';
@Component({
  selector: 'ugc-upload-progress-container',
  templateUrl: './upload-in-progress-container.component.html',
  styleUrls: ['./upload-in-progress-container.component.css']
})
export class UploadInProgressContainerComponent {
}
