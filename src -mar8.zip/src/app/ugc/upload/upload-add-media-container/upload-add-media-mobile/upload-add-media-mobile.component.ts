import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { Router, ActivatedRoute } from '@angular/router';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';
import { UgcC11nJson } from '../../../../ugc-shared/shared-factories/customization.factory';
import { UgcCustomizationService } from
  '../../../../ugc-shared/shared-services/ugc-customization/ugc-customization.service';

@Component({
  selector: 'ugc-upload-add-media-mobile',
  templateUrl: './upload-add-media-mobile.component.html',
  styleUrls: ['./upload-add-media-mobile.component.scss']
})
export class UploadAddMediaMobileComponent implements OnInit {
  public ugcAddLogoUrlSmall: string;
  public ugcAddLogoUrlBig: string;
  public mediaUpload: MediaUpload;
  public fileError: boolean = false;
  public ugcCustomizeConfig: UgcC11nJson;
  public isLogoVisible: boolean;

  constructor(private _changeDetector: ChangeDetectorRef,
    private _mediaUpload: MediaUploadService,
    private _router: Router,
    private _ugcCustomize: UgcCustomizationService) {
    this.ugcCustomizeConfig = this._ugcCustomize.ugcC11n;
    this.isLogoVisible = this.ugcCustomizeConfig.branding.brandingLogoRule === 'B' ? true : false;

    if (this._mediaUpload.mediaUpload && this._mediaUpload.mediaUpload.isActive) {
      this._mediaUpload.resetMediaItems();
    } else {
      this._mediaUpload.createMediaUpload();
      this.mediaUpload = this._mediaUpload.mediaUpload;
    }

  }

  public ngOnInit() {
    this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
    this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
  }

  public fileSelectedMobile(eve: UIEvent) {
    let file: any = eve.target;
    if (this._mediaUpload.fileUploadValidator(file.files)) {
      this._mediaUpload.addMedia(file.files);
      this._router.navigate(['/ugc/upload/media-preview'],
        { queryParams: StaticUtils.queryParams });
      this.fileError = false;
    } else {
      this.fileError = true;
    }

  }

  private onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  private onImageError(event): void {
    this._changeDetector.detectChanges();
  }


}
