import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';


@Component({
  selector: 'ugc-desktop-landing',
  templateUrl: './desktop-landing.component.html',
  styleUrls: ['./desktop-landing.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DesktopLandingComponent {

}
