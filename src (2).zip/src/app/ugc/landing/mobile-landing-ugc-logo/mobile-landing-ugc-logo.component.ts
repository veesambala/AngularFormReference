import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MediaUploadService, MediaUpload } from
  '../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { StaticUtils } from '../../../ugc-shared/shared-services/static-utils';

@Component({
  selector: 'ugc-mobile-landing-ugc-logo',
  templateUrl: './mobile-landing-ugc-logo.component.html',
  styleUrls: ['./mobile-landing-ugc-logo.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MobileLandingUgcLogoComponent implements OnInit {
  public ugcLogoUrl: string;
  public brandingLogoUrl: string;
  public burstLogoUrl: string;
  public ugcbrandingLogoUrl: string;

  public ugcAddLogoUrlSmall: string;
  public ugcAddLogoUrlBig: string;

  constructor(private _changeDetector: ChangeDetectorRef,
              private _mediaUpload: MediaUploadService,
              private _router: Router) {

}

  public ngOnInit() {
    this.burstLogoUrl = 'assets/img/ico-burst-bg-white-logo.svg';
    this.ugcLogoUrl = 'assets/img/ico-ugc-logo.png';
    this.brandingLogoUrl = 'assets/img/ico-branding-logo.png';
    this.ugcbrandingLogoUrl = 'assets/img/ico-ugc-logo.png';
    this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
    this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
  }

  public goToUpload() {
    this._router.navigate(['/ugc/upload'], { queryParams: StaticUtils.queryParams });
  }

  private onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  private onImageError(event): void {
    this._changeDetector.detectChanges();
  }

}