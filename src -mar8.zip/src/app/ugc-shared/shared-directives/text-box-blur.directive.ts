import {Directive, HostListener} from "@angular/core";

@Directive({
  selector: '[text-box-blur]',
})
export class TextBoxBlurDirective {
  constructor() {

  }
  @HostListener('blur', ['$event'])
  onblur(event) {
    debugger;
    let tracker: HTMLElement = event.target;
    let aClassList = (tracker && tracker.classList);
}
}