import { Component } from '@angular/core';
@Component({
  selector: 'ugc-media-terms-conditions-container',
  templateUrl: './media-terms-conditions-container.component.html',
  styleUrls: ['./media-terms-conditions-container.component.scss']
})
export class MediaTermsConditionsContainerComponent {
}
