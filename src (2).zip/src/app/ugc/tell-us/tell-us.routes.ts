import { TellUsComponent } from './tell-us.component';
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

export const routes = [
  { path: '', component: TellUsComponent }
];