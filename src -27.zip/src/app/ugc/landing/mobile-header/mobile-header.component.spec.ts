import { TestBed, async } from '@angular/core/testing';
import { MobileHeaderComponent } from './mobile-header.component';

describe('MobileHeaderComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MobileHeaderComponent
      ],
    }).compileComponents();
  }));
  it('should create the MobileHeaderComponent component', async(() => {
    const fixture = TestBed.createComponent(MobileHeaderComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
