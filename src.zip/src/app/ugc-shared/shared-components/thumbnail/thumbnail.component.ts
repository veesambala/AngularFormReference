import { Component } from '@angular/core';
@Component({
  selector: 'ugc-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent {
}