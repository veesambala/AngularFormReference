import { Component } from '@angular/core';
@Component({
  selector: 'ugc-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent {
}