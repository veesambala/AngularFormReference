import { TestBed, async } from '@angular/core/testing';
import { UploadPromptComponent } from './upload-prompt.component';

describe('UploadPromptComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UploadPromptComponent
      ],
    }).compileComponents();
  }));
  it('should create the UploadPromptComponent component', async(() => {
    const fixture = TestBed.createComponent(UploadPromptComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
