import { Component,ChangeDetectionStrategy,ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'ugc-upload-success-mobile',
  templateUrl: './upload-success-mobile.component.html',
  styleUrls: ['./upload-success-mobile.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadSuccessMobileComponent {
  
  constructor(private _changeDetector: ChangeDetectorRef){
          
  }

  onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  onImageError(event): void {
    this._changeDetector.detectChanges();
  }
}