import { Component } from '@angular/core';
@Component({
  selector: 'ugc-media-preview-container',
  templateUrl: './media-preview-container.component.html',
  styleUrls: ['./media-preview-container.component.css']
})
export class MediaPreviewContainerComponent {
}
