import { Component } from '@angular/core';

export abstract class UserInfoLayoutBase{
    
}