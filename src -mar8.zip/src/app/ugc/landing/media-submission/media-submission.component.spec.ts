import { TestBed, async } from '@angular/core/testing';
import { MediaSubmissionComponent } from './powered-by-burst.component';
describe('MediaSubmissionComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MediaSubmissionComponent
      ],
    }).compileComponents();
  }));
  it('should create the MediaSubmissionComponent ', async(() => {
    const fixture = TestBed.createComponent(MediaSubmissionComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
