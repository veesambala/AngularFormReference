import { Component } from '@angular/core';
@Component({
  selector: 'ugc-desktop-right',
  templateUrl: './desktop-right.component.html',
  styleUrls: ['./desktop-right.component.css']
})
export class DesktopRightComponent {
}