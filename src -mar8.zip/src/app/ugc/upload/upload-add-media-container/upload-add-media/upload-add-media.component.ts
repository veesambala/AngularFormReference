import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { Router, ActivatedRoute } from '@angular/router';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';
import { UgcErrorReportService } from '../../../../ugc-shared/shared-services/ugc-error-report/ugc-error-report.service';
import { UgcC11nJson } from '../../../../ugc-shared/shared-factories/customization.factory';
import { UgcCustomizationService } from
'../../../../ugc-shared/shared-services/ugc-customization/ugc-customization.service';


@Component({
  selector: 'ugc-upload-add-media',
  templateUrl: './upload-add-media.component.html',
  styleUrls: ['./upload-add-media.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadAddMediaComponent {
  public mediaUpload: MediaUpload;
  public ugcAddLogoUrlSmall: string;
  public ugcAddLogoUrlBig: string;
  public uploadError: boolean = false;
  public ugcCustomizeConfig: UgcC11nJson;
  public isLogoVisible: boolean;
  constructor(
    private _changeDetector: ChangeDetectorRef,
    private _mediaUpload: MediaUploadService,
    private _router: Router,
    private _ugcErrorReportService: UgcErrorReportService,
    private _ugcCustomize: UgcCustomizationService
  ) {
    this.ugcCustomizeConfig = this._ugcCustomize.ugcC11n;
    this.isLogoVisible = this.ugcCustomizeConfig.branding.brandingLogoRule === 'B' ? true : false;

    if (this._mediaUpload.mediaUpload && this._mediaUpload.mediaUpload.isActive) {
      this._mediaUpload.resetMediaItems();
    } else {
      this._mediaUpload.createMediaUpload();
      this.mediaUpload = this._mediaUpload.mediaUpload;
    }

    this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
    this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
  }

  public fileSelected(eve: UIEvent) {
    let file: any = eve.target;

    if (this._mediaUpload.fileUploadValidator(file.files)) {
      this._mediaUpload.addMedia(file.files);
      this._ugcErrorReportService.captureFileLogs();
      this._router.navigate(['/ugc/upload/media-preview'],
                            { queryParams: StaticUtils.queryParams });
      this.uploadError = false;
    } else {
      this.uploadError = true;
    }

  }
  public uploadCancelled() {
    this._router.navigate(['/ugc/landing'], { queryParams: StaticUtils.queryParams });
  }

}
