import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StaticUtils } from '../../ugc-shared/services/static-utils';
@Component({
  selector: 'ugc-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
}
