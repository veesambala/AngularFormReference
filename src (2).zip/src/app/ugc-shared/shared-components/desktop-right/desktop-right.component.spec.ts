import { TestBed, async } from '@angular/core/testing';
import { DesktopRightComponent } from './desktop-right';

describe('DesktopRightComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DesktopRightComponent
      ],
    }).compileComponents();
  }));
  it('should create the poweredBy component', async(() => {
    const fixture = TestBed.createComponent(DesktopRightComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
