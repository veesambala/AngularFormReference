import { TestBed, async } from '@angular/core/testing';
import { UploadFIPreviewComponent } from './upload-fi-preview.component';
describe('UploadFIPreviewComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UploadFIPreviewComponent
      ],
    }).compileComponents();
  }));
  it('should create the call-to-action component', async(() => {
    const fixture = TestBed.createComponent(UploadFIPreviewComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
