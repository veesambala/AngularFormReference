import { Component } from '@angular/core';

@Component({
    selector: 'user-info',
    templateUrl: './user-info.component.html',
    styleUrls: ['./user-info.component.scss', './user-info.component.theme.scss']
})
export class UserInfoComponent {

} 