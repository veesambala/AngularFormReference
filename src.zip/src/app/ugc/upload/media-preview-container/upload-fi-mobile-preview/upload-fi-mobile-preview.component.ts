import { Component, ChangeDetectionStrategy, ChangeDetectorRef, } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';

@Component({
  selector: 'ugc-upload-fi-mobile-preview',
  templateUrl: './upload-fi-mobile-preview.component.html',
  styleUrls: ['./upload-fi-mobile-preview.component.scss']
})
export class UploadFIMobilePreviewComponent {
  public mediaTitle: string = '';
  public filesList = [];

  constructor(private _changeDetector: ChangeDetectorRef,
              private _mediaUpload: MediaUploadService,
              private _router: Router) {
    if (this._mediaUpload.mediaUpload.mediaItems.length > 0) {
      this.filesList = this._mediaUpload.mediaUpload.mediaItems;
    }
  }
  public handleNext() {
    if (this.mediaTitle !== '' ) {
      this._mediaUpload.updateMediaTitle(this.mediaTitle);
      this._router.navigate(['/ugc/upload/user-info'], { queryParams: StaticUtils.queryParams });
    }
  }
  public fileSelectedMobile(eve: UIEvent) {
    let file: any = eve.target;
    let allFiles = [];
    if (this.filesList.length > 0) {
      for (let value of this.filesList) {
        allFiles.push(value.blob);
      }
      for (let value of file.files) {
        allFiles.push(value);
      }
    }
    if (this._mediaUpload.fileUploadValidator(allFiles)) {
      this._mediaUpload.addMedia(file.files);
    }
  }
  public fileRemoved(fileIndex: number) {
    this.filesList.splice(fileIndex, 1);
  }
  public onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  public onImageError(event): void {
    this._changeDetector.detectChanges();
  }
}