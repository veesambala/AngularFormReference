import { Component } from '@angular/core';

@Component({
  selector: 'ugc-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class UgcLandingComponent {

}
