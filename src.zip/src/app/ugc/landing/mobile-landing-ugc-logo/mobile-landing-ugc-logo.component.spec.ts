import { TestBed, async } from '@angular/core/testing';
import { MobileLandingUgcLogoComponent } from './mobile-landing-ugc-logo.component';

describe('MobileLandingUgcLogoComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MobileLandingUgcLogoComponent
      ],
    }).compileComponents();
  }));
  it('should create the MobileLandingUgcLogoComponent component', async(() => {
    const fixture = TestBed.createComponent(MobileLandingUgcLogoComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
