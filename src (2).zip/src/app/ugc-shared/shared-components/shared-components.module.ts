import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'
import { CheckboxComponent } from './checkbox/checkbox.component';
import { ListComponent } from './list/list.component';
import { LogoComponent } from './logo/logo.component';
import { PageProgressComponent } from './page-progress/page-progress.component';
import { UploadProgressComponent } from './upload-progress/upload-progress.component';
import { PreviewComponent } from './preview/preview.component';
import { ProgressComponent } from './Progress/progress.component';
import { ThumbnailComponent } from './thumbnail/thumbnail.component';
import { DesktopRightComponent } from './desktop-right/desktop-right.component';
import { ScrolldownComponent } from './scroll-down-component/scrolldown.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { DefaultConfig } from '../shared-factories/default-loader-config.factory';
@NgModule({
  declarations: [
    /**
     * Components / Directives/ Pipes
     */
    CheckboxComponent,
    ListComponent,
    LogoComponent,
    PageProgressComponent,
    PreviewComponent,
    ProgressComponent,
    ThumbnailComponent,
    DesktopRightComponent,
    ScrolldownComponent,
    UploadProgressComponent
  ],
  imports: [
    CommonModule,
    NgCircleProgressModule.forRoot(DefaultConfig),
  ],
  exports: [
    CheckboxComponent,
    ListComponent,
    LogoComponent,
    PageProgressComponent,
    PreviewComponent,
    ProgressComponent,
    ThumbnailComponent,
    DesktopRightComponent,
    UploadProgressComponent
  ]
})
export class sharedComponentsModule {

}
