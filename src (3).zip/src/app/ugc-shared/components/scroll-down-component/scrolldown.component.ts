import { Component } from '@angular/core';
@Component({
  selector: 'ugc-scrolldown',
  templateUrl: './scrolldown.component.html',
  styleUrls: ['./scrolldown.component.css']
})
export class ScrolldownComponent {
}