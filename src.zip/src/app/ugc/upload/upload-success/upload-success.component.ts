import { ChangeDetectionStrategy,ChangeDetectorRef,Component } from '@angular/core';
@Component({
  selector: 'ugc-upload-success',
  templateUrl: './upload-success.component.html',
  styleUrls: ['./upload-success.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadSuccessComponent {
  
  constructor(private _changeDetector: ChangeDetectorRef){
          
  }
  onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  onImageError(event): void {
    this._changeDetector.detectChanges();
  }
}