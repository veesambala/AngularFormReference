import { TestBed, async } from '@angular/core/testing';
import { PoweredByComponent } from './powered-by-burst.component';
describe('PoweredByComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PoweredByComponent
      ],
    }).compileComponents();
  }));
  it('should create the poweredBy component', async(() => {
    const fixture = TestBed.createComponent(PoweredByComponent);
    const comp = fixture.debugElement.componentInstance;
    expect(comp).toBeTruthy();
  }));
});
