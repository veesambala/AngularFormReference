import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { LandingComponent } from './landing.component';
import { PoweredByComponent } from './powered-by-burst/powered-by-burst.component';
import { routes } from './landing.routes';
import { DesktopLandingComponent } from './desktop-landing/desktop-landing.component';
import { UploadPromptComponent } from './upload-prompt/upload-prompt.component';
import { MobileHeaderComponent } from './mobile-header/mobile-header.component';
import { BrandingLogoComponent } from './branding-logo/branding-logo.component';
import { MediaSubmissionComponent } from './media-submission/media-submission.component';
import { sharedComponentsModule } from
'../../ugc-shared/shared-components/shared-components.module';
import { MobileLandingUgcLogoComponent } from
'./mobile-landing-ugc-logo/mobile-landing-ugc-logo.component';

@NgModule({
    declarations: [
        LandingComponent,
        PoweredByComponent,
        MobileLandingUgcLogoComponent,
        DesktopLandingComponent,
        UploadPromptComponent,
        MobileHeaderComponent,
        BrandingLogoComponent,
        MediaSubmissionComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        sharedComponentsModule,
        RouterModule.forChild(routes)
    ],
    exports: []
})
export class LandingModule {

}
