import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { Router, ActivatedRoute } from '@angular/router';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';

@Component({
  selector: 'ugc-upload-fi-preview',
  templateUrl: './upload-fi-preview.component.html',
  styleUrls: ['./upload-fi-preview.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadFIPreviewComponent {
  public ugcLogo: string;
  public mediaTitle: string = '';
  public filesList = [];

  constructor(private _changeDetector: ChangeDetectorRef,
    private _mediaUpload: MediaUploadService,
    private _router: Router) {
    this.ugcLogo = 'assets/img/ico-upload-logo.png';
    if (this._mediaUpload.mediaUpload.mediaItems.length > 0) {
      this.filesList = this._mediaUpload.mediaUpload.mediaItems;
    }
    console.log('filesList', this.filesList);
  }

  public handleNext() {
    if (this.mediaTitle !== '') {
      this._mediaUpload.updateMediaTitle(this.mediaTitle);
      localStorage.setItem('mediatitle', this.mediaTitle);
      this._router.navigate(['/ugc/upload/user-info'], { queryParams: StaticUtils.queryParams });
    }
  }

  public addtionalFileSelected(eve: UIEvent) {
    let file: any = eve.target;
    let allFiles = [];
    if (this.filesList.length > 0) {
      for (let value of this.filesList) {
        allFiles.push(value.blob);
      }
      for (let value of file.files) {
        allFiles.push(value);
      }
    }
    if (this._mediaUpload.fileUploadValidator(allFiles)) {
      this._mediaUpload.addMedia(file.files);
    }
  }

  public handleResteCancelBtn(isNavigateToLanding) {
    this.mediaTitle = '';
    this._mediaUpload.mediaUpload.mediaItems = [];
    if (isNavigateToLanding) {
      this._router.navigate(['/ugc/landing'], { queryParams: StaticUtils.queryParams });
    } else {
      this._router.navigate(['/ugc/upload/add-media'], { queryParams: StaticUtils.queryParams });
    }
  }

  public fileRemoved(fileIndex: number) {
    this.filesList.splice(fileIndex, 1);
  }

  public onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  public onImageError(event): void {
    this._changeDetector.detectChanges();
  }
}