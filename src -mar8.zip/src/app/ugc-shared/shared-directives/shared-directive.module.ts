import { NgModule } from '@angular/core';
import { TextBoxBlurDirective } from './text-box-blur.directive';
@NgModule({
  declarations: [
    /**
     * Components / Directives/ Pipes
     */
    TextBoxBlurDirective
  ],
  imports: [],
  exports: [
    TextBoxBlurDirective
  ]
})
export class sharedDirectiveModule {
 
}

