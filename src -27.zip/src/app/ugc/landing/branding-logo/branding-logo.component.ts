import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UgcCustomizationService } from
    '../../../ugc-shared/shared-services/ugc-customization/ugc-customization.service';
import { UgcC11nJson } from '../../../ugc-shared/shared-factories/customization.factory';

@Component({
    selector: 'ugc-branding-logo',
    templateUrl: './branding-logo.component.html',
    styleUrls: ['./branding-logo.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class BrandingLogoComponent {

    public ugcbrandingLogoUrl: string;
    public brandingLogoUrl: string;
    public burstLogoUrl: string;
    public ugcLogoUrl: string;
    public ugcCustomizeConfig: UgcC11nJson;
    public showUgcBrandSposorLogo: boolean;
    public showUgcBrandingLogo: boolean;
    public showBurstDefault: boolean;

    constructor(private _changeDetector: ChangeDetectorRef,
                private _ugcCustomize: UgcCustomizationService) {
        this.burstLogoUrl = 'assets/img/ico-burst-bg-white-logo.svg';
        this.brandingLogoUrl = 'assets/img/ico-branding-logo.png';
        this.ugcbrandingLogoUrl = 'assets/img/ico-ugc-logo.png';
        this.ugcCustomizeConfig = this._ugcCustomize.ugcC11n;
        this.setUgcCustomLogoConfig();

    }
    private setUgcCustomLogoConfig() {
        if (this.ugcCustomizeConfig.branding.custBrandingLogo !== '' &&
            this.ugcCustomizeConfig.branding.sponsorBrandingLogo !== '') {
            this.showUgcBrandSposorLogo = true;
            this.showUgcBrandingLogo = false;
            this.showBurstDefault = false;
        } else if (this.ugcCustomizeConfig.branding.custBrandingLogo !== '' &&
            this.ugcCustomizeConfig.branding.sponsorBrandingLogo === '') {
            this.showUgcBrandSposorLogo = false;
            this.showUgcBrandingLogo = true;
            this.showBurstDefault = false;
        } else {
            this.showUgcBrandSposorLogo = false;
            this.showUgcBrandingLogo = false;
            this.showBurstDefault = true;
        }
    }
    private onImageLoaded(event): void {
        this._changeDetector.detectChanges();
    }

    private onImageError(event): void {
        this._changeDetector.detectChanges();
    }


}