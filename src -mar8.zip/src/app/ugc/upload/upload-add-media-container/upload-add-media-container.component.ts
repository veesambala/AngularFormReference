import { Component } from '@angular/core';
@Component({
  selector: 'ugc-upload-add-media-container',
  templateUrl: './upload-add-media-container.component.html',
  styleUrls: ['./upload-add-media-container.component.css']
})
export class UploadAddMediaContainerComponent {
}
