import { Component } from '@angular/core';
@Component({
  selector: 'add-media',
  templateUrl: './add-media.component.html',
  styleUrls: ['./add-media.component.scss', './add-media.component.theme.scss']
})
export class AddMediaComponent {
}
