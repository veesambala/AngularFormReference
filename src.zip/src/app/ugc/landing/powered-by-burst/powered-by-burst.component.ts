import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

@Component({
  selector: 'ugc-powered-by-burst',
  templateUrl: './powered-by-burst.component.html',
  styleUrls: ['./powered-by-burst.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PoweredByComponent {
  constructor(private _changeDetector: ChangeDetectorRef) {

  }
}