import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { Router, ActivatedRoute } from '@angular/router';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';

@Component({
  selector: 'ugc-upload-add-media-mobile',
  templateUrl: './upload-add-media-mobile.component.html',
  styleUrls: ['./upload-add-media-mobile.component.css']
})
export class UploadAddMediaMobileComponent implements OnInit {
  public ugcAddLogoUrlSmall: string;
  public ugcAddLogoUrlBig: string;
  public mediaUpload: MediaUpload;
  public fileError: boolean = false;

  constructor(private _changeDetector: ChangeDetectorRef,
              private _mediaUpload: MediaUploadService,
              private _router: Router) {

    if (this._mediaUpload.mediaUpload && this._mediaUpload.mediaUpload.isActive) {
      this._mediaUpload.resetMediaItems();
    } else {
      this._mediaUpload.createMediaUpload();
      this.mediaUpload = this._mediaUpload.mediaUpload;
    }

  }

  public ngOnInit() {
    this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
    this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
  }

  public fileSelectedMobile(eve: UIEvent) {
    let file: any = eve.target;
    if (this._mediaUpload.fileUploadValidator(file.files)) {
      this._mediaUpload.addMedia(file.files);
      this._router.navigate(['/ugc/upload/media-preview'],
                            { queryParams: StaticUtils.queryParams });
      this.fileError = false;
    }else {
      this.fileError = true;
    }

  }

  private onImageLoaded(event): void {
    this._changeDetector.detectChanges();
  }

  private onImageError(event): void {
    this._changeDetector.detectChanges();
  }


}
