import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UgcCustomizationService } from
    '../../../ugc-shared/shared-services/ugc-customization/ugc-customization.service';
import { UgcC11nJson } from '../../../ugc-shared/shared-factories/customization.factory';

@Component({
    selector: 'ugc-mobile-header',
    templateUrl: './mobile-header.component.html',
    styleUrls: ['./mobile-header.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MobileHeaderComponent {

    public ugcbrandingLogoUrl: string;
    public ugcAddLogoUrlSmall: string;
    public brandingLogoUrl: string;
    public ugcAddLogoUrlBig: string;
    public mediatext: string;
    public ugcCustomizeConfig: UgcC11nJson;
    public isLogoVisible: boolean;
    constructor(private _changeDetector: ChangeDetectorRef,
                private _ugcCustomize: UgcCustomizationService) {
        this.brandingLogoUrl = 'assets/img/ico-branding-logo.png';
        this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
        this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
        this.ugcbrandingLogoUrl = 'assets/img/ico-ugc-logo.png';
        this.ugcCustomizeConfig = this._ugcCustomize.ugcC11n;
        this.isLogoVisible = this.ugcCustomizeConfig.branding.brandingLogoRule === 'B' ? true : false;
    }

    private onImageLoaded(event): void {
        this._changeDetector.detectChanges();
    }

    private onImageError(event): void {
        this._changeDetector.detectChanges();
    }


}