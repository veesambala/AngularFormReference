import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

@Component({
  selector: 'ugc-media-submission',
  templateUrl: './media-submission.component.html',
  styleUrls: ['./media-submission.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaSubmissionComponent {
  constructor(private _changeDetector: ChangeDetectorRef) {

  }
}