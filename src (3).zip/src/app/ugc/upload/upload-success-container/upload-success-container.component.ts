import { Component } from '@angular/core';
@Component({
  selector: 'ugc-upload-success-container',
  templateUrl: './upload-success-container.component.html',
  styleUrls: ['./upload-success-container.component.scss']
})
export class UploadSuccessContainerComponent {
}
