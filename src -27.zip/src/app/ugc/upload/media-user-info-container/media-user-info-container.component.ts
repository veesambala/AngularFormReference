import { Component } from '@angular/core';
@Component({
  selector: 'ugc-media-user-info-container',
  templateUrl: './media-user-info-container.component.html',
  styleUrls: ['./media-user-info-container.component.css']
})
export class MediaUserInfoContainerComponent {
}
