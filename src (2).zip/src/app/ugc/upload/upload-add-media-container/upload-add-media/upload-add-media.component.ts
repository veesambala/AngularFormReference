import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { MediaUploadService, MediaUpload } from
  '../../../../ugc-shared/shared-services/media-upload/media-upload.service';
import { Router, ActivatedRoute } from '@angular/router';
import { StaticUtils } from '../../../../ugc-shared/shared-services/static-utils';
import { UgcErrorReportService } from '../../../../ugc-shared/shared-services/ugc-error-report/ugc-error-report.service';

@Component({
  selector: 'ugc-upload-add-media',
  templateUrl: './upload-add-media.component.html',
  styleUrls: ['./upload-add-media.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadAddMediaComponent {
  public mediaUpload: MediaUpload;
  public ugcAddLogoUrlSmall: string;
  public ugcAddLogoUrlBig: string;
  public uploadError: boolean = false;
  constructor(
    private _changeDetector: ChangeDetectorRef,
    private _mediaUpload: MediaUploadService,
    private _router: Router,
    private _ugcErrorReportService: UgcErrorReportService
  ) {

    if (this._mediaUpload.mediaUpload && this._mediaUpload.mediaUpload.isActive) {
      this._mediaUpload.resetMediaItems();
    } else {
      this._mediaUpload.createMediaUpload();
      this.mediaUpload = this._mediaUpload.mediaUpload;
    }

    this.ugcAddLogoUrlSmall = 'assets/img/ico-upload-logo.png';
    this.ugcAddLogoUrlBig = 'assets/img/ico-upload-logo.png';
  }

  public fileSelected(eve: UIEvent) {
    let file: any = eve.target;

    if (this._mediaUpload.fileUploadValidator(file.files)) {
      this._mediaUpload.addMedia(file.files);
      this._ugcErrorReportService.captureFileLogs();
      this._router.navigate(['/ugc/upload/media-preview'],
                            { queryParams: StaticUtils.queryParams });
      this.uploadError = false;
    } else {
      this.uploadError = true;
    }

  }
  public uploadCancelled() {
    this._router.navigate(['/ugc/landing'], { queryParams: StaticUtils.queryParams });
  }

}
