import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StaticUtils } from '../../ugc-shared/shared-services/static-utils';
@Component({
  selector: 'ugc-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  public aFiles: Array<any> = [];
  


  constructor(
    public router: Router
  ) {

  }

 
}