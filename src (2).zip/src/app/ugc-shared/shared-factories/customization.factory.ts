import { BaseFactory } from './base.factory';

export class CustomizationFactory {
   /**
    * @param c11nJsonObject The javascript object to convert into a C11nJson
    * @param enforce {boolean} If the creation should enforce structure and known types.
    *                if true will throw errors for missing, false to add the errors to errors array
    * @param objectName  Name of container object.
    * @return {Array<string>} array of all validation errors
    */
  public static validateC11nJson(c11nJsonObject: any, objectName: string, enforce: boolean):Array<string> {
    let validationErrors: Array<string> = [];
    let c11nJson: UgcC11nJson = BaseFactory.validateObject<UgcC11nJson>(c11nJsonObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'bubbleId', {}, enforce, validationErrors);
    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'ugcLink', {}, enforce, validationErrors);
    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'ugcSubmissionType', {}, enforce, validationErrors);
    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'enableBrowserLocationPromptRule', {}, enforce, validationErrors);
    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'returnUrl', {}, enforce, validationErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'user', {}, enforce, validationErrors);
    let userErrors: Array<string> =  CustomizationFactory.validateUgcUser(c11nJson.user, 'user', enforce);
    validationErrors.push.apply(validationErrors, userErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'branding', {}, enforce, validationErrors);
    let brandingErrors: Array<string> =  CustomizationFactory.validateUgcBranding(c11nJson.branding, 'branding', enforce);
    validationErrors.push.apply(validationErrors, brandingErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'termsAndConditions', {}, enforce, validationErrors);
    let termsAndConditionErrors: Array<string> =  CustomizationFactory.validateUgcTermsAndConditions(c11nJson.termsAndConditions, 'termsAndConditions', enforce);
    validationErrors.push.apply(validationErrors, termsAndConditionErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'theme', {}, enforce, validationErrors);
    let themeErrors: Array<string> =  CustomizationFactory.validateUgcTheme(c11nJson.theme, 'theme', enforce);
    validationErrors.push.apply(validationErrors, themeErrors);

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'formFields', {}, enforce, validationErrors);
    Object.keys(c11nJson.formFields).forEach((key) => {
      let formFieldErrors: Array<string> = CustomizationFactory.validateFormFields(c11nJson.formFields[key], objectName, enforce);
      validationErrors.push.apply(validationErrors, formFieldErrors);
    });

    BaseFactory.validateObjectField<object>(c11nJson, objectName, 'locales', {}, enforce, validationErrors);
    let localeErrors: Array<string> =  CustomizationFactory.validateLocales(c11nJson.locales, 'locales', enforce);
    validationErrors.push.apply(validationErrors, localeErrors);

    return validationErrors;
  }

  /**
   * @param localesObject The javascript object to convert into a Locales
   * @param enforce {boolean} If the creation should enforce structure and known types.
   *                          if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateLocales(localesObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let locales: Locales = BaseFactory.validateObject<Locales>(localesObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<string>(locales, objectName, 'default', 'en-us', enforce, validationErrors);
    BaseFactory.validateObjectField<any>(locales, objectName, 'supported', {}, enforce, validationErrors);

    Object.keys(locales.supported).forEach((key) => {
      let localeErrors: Array<string> = CustomizationFactory.validateLocale(locales.supported[key], objectName, enforce);
      validationErrors.push.apply(validationErrors, localeErrors);
    });
    locales._current = null;
    locales.current = (): Locale => {
      if (locales._current) {
        return locales._current;
      }

      let userLocale = navigator.language.toLowerCase().replace('_', '-');

      if (locales.supported.hasOwnProperty(userLocale)) {
        locales._current = locales.supported[userLocale];
      } else if (locales.supported.hasOwnProperty(locales.default)) {
        locales._current = locales.supported[locales.default];
        validationErrors.push('Could not load user locale of ' + userLocale);
      } else {
        let fallBack: object = {};
        CustomizationFactory.validateLocale(fallBack, objectName, false);
        locales._current = fallBack as Locale;
        validationErrors.push('Could not load user locale of ' + userLocale + ' or default locale of ' + locales.default);
      }

      return locales._current;
    };
    locales.current(); // invoke so that locale is immediately ready to go and if there are any issues they are placed into errors array

    return validationErrors;
  }

  /**
   * @param localeObject The javascript object to convert into a Locale
   * @param enforce {boolean} If the creation should enforce structure and known types.
   *                          if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateLocale(localeObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let locale: Locale = BaseFactory.validateObject<Locale>(localeObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<any>(locale, objectName, 'formField', {}, enforce, validationErrors);

    Object.keys(locale.formField).forEach((key) => {
      let formFieldlocaleErrors: Array<string> = CustomizationFactory.validateLocaleFormField(locale.formField[key], objectName, enforce);
      validationErrors.push.apply(validationErrors, formFieldlocaleErrors);
    });

    BaseFactory.validateObjectField<string>(locale, objectName, 'landingPageHeadlineText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'landingPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'landingPageTipText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'formPageHeadlineText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'formPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'termsAndConditionsPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'termsAndConditionsAutoAcceptText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'termsAndConditionsManualAcceptText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultLandingPageHeadlineText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultLandingPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultLandingPageTipText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultFormPageHeadlineText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultFormPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultTermsAndConditionsPageTitle', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultTermsAndConditionsAutoAcceptText', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(locale, objectName, 'defaultTermsAndConditionsManualAcceptText', '', enforce, validationErrors);
    return validationErrors;
  }

  /**
   * @param UgcLocaleFormFieldObject The javascript object to convert into a UgcThemeObject
   * @param enforce  {boolean} If the creation should enforce structure and known types.
   * if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateLocaleFormField(UgcLocaleFormFieldObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let UgcLocaleFromFieldObj: FormFieldsLocale = BaseFactory.validateObject<FormFieldsLocale>(UgcLocaleFormFieldObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<string>(UgcLocaleFromFieldObj, objectName, 'placeholder', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcLocaleFromFieldObj, objectName, 'label', '', enforce, validationErrors);
    return validationErrors;
 }


  /**
   * 
   * @param UgcFormFieldObject The javascript object to convert into a UgcFormFieldObject
   * @param enforce  {boolean} If the creation should enforce structure and known types.
   * if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateFormFields(UgcFormFieldObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let UgcFromFieldObj: FormFields = BaseFactory.validateObject<FormFields>(UgcFormFieldObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<string>(UgcFromFieldObj, objectName, 'fieldName', '', enforce, validationErrors);
    BaseFactory.validateObjectField<boolean>(UgcFromFieldObj, objectName, 'isFieldRequired', false, enforce, validationErrors);
    BaseFactory.validateObjectField<boolean>(UgcFromFieldObj, objectName, 'isFieldVisible', true, enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcFromFieldObj, objectName, 'fieldOrder', '', enforce, validationErrors);
    return validationErrors;
 }
  
  /**
   * 
   * @param UgcThemeObject The javascript object to convert into a UgcThemeObject
   * @param enforce  {boolean} If the creation should enforce structure and known types.
   * if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateUgcTheme(UgcThemeObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let UgcThemeObj: Theme = BaseFactory.validateObject<Theme>(UgcThemeObject, objectName, enforce, validationErrors);

    BaseFactory.validateObjectField<string>(UgcThemeObj, objectName, 'cssUrl', '', enforce, validationErrors);
    return validationErrors;
 }

  /**
   * 
   * @param UgcTCObject The javascript object to convert into a UgcTCObject
   * @param enforce  {boolean} If the creation should enforce structure and known types.
   * if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
   public static validateUgcTermsAndConditions(UgcTCObject: any, objectName: string, enforce: boolean): Array<string> {
      let validationErrors: Array<string> = [];
      let UgcTermsAndConditionsObj: TermsAndConditions = BaseFactory.validateObject<TermsAndConditions>(UgcTCObject, objectName, enforce, validationErrors);

      BaseFactory.validateObjectField<string>(UgcTermsAndConditionsObj, objectName, 'termsAndConditionsFlowRule', '', enforce, validationErrors);
      BaseFactory.validateObjectField<boolean>(UgcTermsAndConditionsObj, objectName, 'termsAndConditionsSessionRepeatRule', false, enforce, validationErrors);
      BaseFactory.validateObjectField<number>(UgcTermsAndConditionsObj, objectName, 'termsAndConditionsId', null, enforce, validationErrors);
      BaseFactory.validateObjectField<any>(UgcTermsAndConditionsObj, objectName, 'ugcTermsAndConditionsResp', null, enforce, validationErrors);
      return validationErrors;
   }

  /**
   *
   * @param UgcBrandingObject The javascript object to convert into a UgcBrandingObject
   * @param enforce {boolean} If the creation should enforce structure and known types.
   * if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
  public static validateUgcBranding(UgcBrandingObject: any, objectName: string, enforce: boolean): Array<string> {
    let validationErrors: Array<string> = [];
    let UgcBranding: Branding = BaseFactory.validateObject<Branding>(UgcBrandingObject, objectName, enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcBranding, objectName, 'brandingLogoRule', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcBranding, objectName, 'brandingLogoUrl', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcBranding, objectName, 'accountLogoUrl', '', enforce, validationErrors);
    BaseFactory.validateObjectField<true>(UgcBranding, objectName, 'poweredByBustLogo', true, enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcBranding, objectName, 'custBrandingLogo', '', enforce, validationErrors);
    BaseFactory.validateObjectField<string>(UgcBranding, objectName, 'sponsorBrandingLogo', '', enforce, validationErrors);

    return validationErrors;
  }

  /**
   * @param UgcUserObject The javascript object to convert into a UgcUserObject
   * @param enforce {boolean} If the creation should enforce structure and known types.
   *                          if true will throw errors for missing, false to add the errors to errors array
   * @param objectName  Name of container object.
   * @return {Array<string>} array of all validation errors
   */
      public static validateUgcUser(UgcUserObject: any, objectName: string, enforce: boolean): Array<string> {
        let validationErrors: Array<string> = [];
        let UgcUser: User = BaseFactory.validateObject<User>(UgcUserObject, objectName, enforce, validationErrors);

        BaseFactory.validateObjectField<boolean>(UgcUser, objectName, 'hasNonUserInfoFormFields', false , enforce, validationErrors);
        BaseFactory.validateObjectField<boolean>(UgcUser, objectName, 'ugcSubmissionAllowed', false , enforce, validationErrors);
        BaseFactory.validateObjectField<boolean>(UgcUser, objectName, 'burstUser', false , enforce, validationErrors);
        return validationErrors;
      }
}


/**
 * Interface that defines the fields and methods expected for a customization json file of UGC
 */
export interface UgcC11nJson {
  bubbleId: string;
  ugcLink: string;
  ugcSubmissionType: string;
  enableBrowserLocationPromptRule: boolean;
  returnUrl: string;
  user: User;
  branding: Branding;
  formFields: FormFields;
  termsAndConditions: TermsAndConditions;
  theme: Theme;
  locales: Locales;
}

/**
 * Interface that defines the 'user'
 */
export interface User {
  hasNonUserInfoFormFields: boolean;
  ugcSubmissionAllowed: boolean;
  burstUser: boolean;
}

/**
 * Interface defining Branding fields
 */
export interface Branding {
  brandingLogoRule: string;
  brandingLogoUrl: string;
  accountLogoUrl: string;
  poweredByBustLogo: boolean;
  custBrandingLogo: string;
  sponsorBrandingLogo: string;
}

/**
 * Interface defining Formfields and items
 */
export interface FormFields extends Array<FieldsItems>{}
export interface FieldsItems {
  fieldName: string;
  isFieldRequired: boolean;
  isFieldVisible: boolean;
  fieldOrder: number;
}

/**
 * Interface defining TermsAndConditions
 */
export interface TermsAndConditions {
  termsAndConditionsFlowRule: string;
  termsAndConditionsSessionRepeatRule: boolean;
  termsAndConditionsId: number;
  ugcTermsAndConditionsResp: any;
}

/**
 * Interface defining Theme
 */
export interface Theme {
  cssUrl: string;
}

/**
 * Interface defining Locales
 */
export interface Locales {
  default: string;
  supported: {
    [key: string]: Locale;
  };
  _current: Locale;
  current(): Locale;
}

/**
 * interface defining supported locales
 */
export interface Locale {
  formField: {
    [key: string]: FormFieldsLocale;
  };
  landingPageHeadlineText: string;
  landingPageTitle: string;
  landingPageTipText: string;
  formPageHeadlineText: string;
  formPageTitle: string;
  termsAndConditionsPageTitle: string;
  termsAndConditionsAutoAcceptText: string;
  termsAndConditionsManualAcceptText: string;
  defaultLandingPageHeadlineText: string;
  defaultLandingPageTitle: string;
  defaultLandingPageTipText: string;
  defaultFormPageHeadlineText: string;
  defaultFormPageTitle: string;
  defaultTermsAndConditionsPageTitle: string;
  defaultTermsAndConditionsAutoAcceptText: string;
  defaultTermsAndConditionsManualAcceptText: string;

}

export interface FormFieldsLocale {
  placeholder: string;
  label: string;
}
