import { Routes, RouterModule } from '@angular/router';
import { UploadComponent } from './upload.component';
import { ModuleWithProviders } from '@angular/core';
import { UploadAddMediaContainerComponent } from './upload-add-media-container/upload-add-media-container.component';
import { MediaPreviewContainerComponent } from './media-preview-container/media-preview-container.component';
import { MediaUserInfoContainerComponent } from './media-user-info-container/media-user-info-container.component';
import { UploadConfirmComponent } from './upload-confirm/upload-confirm.component';
import { UploadTermsConditionsComponent } from './media-terms-conditions-container/upload-terms-conditions/upload-terms-conditions.component';
import { UploadSuccessComponent } from './upload-success/upload-success.component';
import { UploadInProgressContainerComponent } from './upload-in-progress-container/upload-in-progress-container.component';
export const routes = [{
  path: '',
  component: UploadComponent,
  children: [
      { path: '', redirectTo: 'add-media' },
      { path: 'add-media', component: UploadAddMediaContainerComponent },
      { path: 'media-preview', component: MediaPreviewContainerComponent },
      { path: 'user-info', component: MediaUserInfoContainerComponent },
      { path: 'upload-confirm', component: UploadConfirmComponent },
      { path: 'terms-conditions', component: UploadTermsConditionsComponent },
      { path : 'upload-inprogress', component: UploadInProgressContainerComponent },
      { path: 'upload-success', component: UploadSuccessComponent }
  ]
}]
