// import { TestBed, async } from '@angular/core/testing';
// import { listComponent} from './list.component';
// describe('listComponent', () => {
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [
//         listComponent
//       ],
//     }).compileComponents();
//   }));
//   it('should create the listComponent', async(() => {
//     const fixture = TestBed.createComponent(listComponent);
//     const comp = fixture.debugElement.componentInstance;
//     expect(comp).toBeTruthy();
//   }));
// });
// // 